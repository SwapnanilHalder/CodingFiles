package main

import (
	"FirstApp/pkg/Router"
	"fmt"
)

func main() {
	fmt.Println("Starting Server....")
	Router.StartServer()
}
